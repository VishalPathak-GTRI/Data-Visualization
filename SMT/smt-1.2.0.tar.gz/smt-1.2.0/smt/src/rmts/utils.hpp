#ifndef __utils_CPP__
#define __utils_CPP__

void expand_index(int nx, int * nlist, int index, int * ilist);
int contract_index(int nx, int * nlist, int * ilist);

#endif
